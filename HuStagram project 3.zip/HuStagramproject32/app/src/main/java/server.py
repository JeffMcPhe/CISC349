from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from datetime import datetime

app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/hustagram"
mongo = PyMongo(app)

@app.route("/upload", methods=["POST"])
def upload_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    image = request.files['image']
    if image.filename == '':
        return jsonify({'error': 'No image selected'}), 400

    # Save image to server
    image_name = datetime.now().strftime("%Y%m%d%H%M%S") + '.jpg'
    image.save('images/' + image_name)

    # Save image details to MongoDB
    comment = request.form.get('comment', '')
    upload_date = datetime.now()

    image_data = {
        'name': image_name,
        'comment': comment,
        'upload_date': upload_date
    }
    mongo.db.images.insert_one(image_data)

    return jsonify({'message': 'Image uploaded successfully'}), 200

@app.route("/images", methods=["GET"])
def get_images():
    images = []
    for image_data in mongo.db.images.find():
        images.append({
            'name': image_data['name'],
            'comment': image_data['comment'],
            'upload_date': image_data['upload_date']
        })
    return jsonify(images), 200

if __name__ == "__main__":
    app.run(debug=True)
