package com.example.logintwoactivity;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        TextView greetingTextView = findViewById(R.id.greetingTextView);

        // Get username passed from LoginActivity
        String username = getIntent().getStringExtra("username");
        String greetingMessage = "Welcome, " + username + "!";
        greetingTextView.setText(greetingMessage);
    }
}


