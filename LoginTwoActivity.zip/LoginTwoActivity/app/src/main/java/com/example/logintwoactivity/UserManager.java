package com.example.logintwoactivity;
import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private static List<User> userList = new ArrayList<>();

    // Initialize hardcoded users
    static {
        userList.add(new User("user1", "password1"));
        userList.add(new User("user2", "password2"));
        // Add more users as needed
    }

    // Validate user credentials
    public static User login(String username, String password) {
        for (User user : userList) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }
}
