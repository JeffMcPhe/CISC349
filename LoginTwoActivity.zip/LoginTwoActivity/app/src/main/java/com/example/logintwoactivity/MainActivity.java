package com.example.logintwoactivity;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assuming MainActivity.java is used as a launcher activity
        // You can add any initialization logic here if needed
    }

    // Add this method if you want to navigate to LoginActivity when MainActivity is started
    @Override
    protected void onStart() {
        super.onStart();
        // Start LoginActivity when MainActivity is started
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        // Finish MainActivity so that it's not shown when user presses back button
        finish();
    }
}
