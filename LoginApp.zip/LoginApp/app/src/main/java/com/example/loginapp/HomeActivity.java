package com.example.loginapp;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    TextView textViewGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textViewGreeting = findViewById(R.id.textViewGreeting);

        String username = getIntent().getStringExtra("USERNAME");
        textViewGreeting.setText("Welcome, " + username + "!");
    }
}
