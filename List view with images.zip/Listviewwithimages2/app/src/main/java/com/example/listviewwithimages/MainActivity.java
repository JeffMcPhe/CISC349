package com.example.listviewwithimages;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create a list of hardcoded users
        ArrayList<User> users = new ArrayList<>();
        users.add(new User("John", R.drawable.user1_image, "john was here"));
        users.add(new User("Alice", R.drawable.user2_image, "alice was here"));
        users.add(new User("Bob", R.drawable.user_default, "bob was here"));

        // Create an adapter to convert the array to views
        final UserAdapter adapter = new UserAdapter(this, users);

        // Attach the adapter to a ListView
        final ListView listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        // Set an item click listener on the ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the user that was clicked
                User clickedUser = (User) parent.getItemAtPosition(position);

                // Create an intent to open the user details activity
                Intent intent = new Intent(MainActivity.this, UserDetailsActivity.class);
                // Pass the clicked user's details to the user details activity
                intent.putExtra("USER_NAME", clickedUser.getName());
                intent.putExtra("USER_DESCRIPTION", clickedUser.getDescription());
                intent.putExtra("USER_IMAGE", clickedUser.getImageResourceId());

                // Start the user details activity
                startActivity(intent);
            }
        });
    }
}