package com.example.listviewwithimages;

import java.io.Serializable;

public class User implements Serializable {
    private String name;
    private int imageResourceId;
    private String bio; // Add the bio property

    // Constructor
    public User(String name, int imageResourceId, String bio) {
        this.name = name;
        this.imageResourceId = imageResourceId;
        this.bio = bio; // Initialize the bio property
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    // Getter for bio
    public String getDescription() {
        return bio;
    }
}
