package com.example.listviewwithimages;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class UserDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        // Retrieve user object from intent extras
        User user = (User) getIntent().getSerializableExtra("user");

        if (user != null) {
            // Set user details to views
            ImageView imageView = findViewById(R.id.imageView);
            TextView nameTextView = findViewById(R.id.nameTextView);
            TextView bioTextView = findViewById(R.id.descriptionTextView);

            imageView.setImageResource(user.getImageResourceId());
            nameTextView.setText(user.getName());
            bioTextView.setText(user.getDescription());
        }
    }
}