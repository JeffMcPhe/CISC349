package com.example.calculatorapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView displayTextView;
    private Button[] digitButtons;
    private Button[] operationButtons;
    private Button equalsButton;
    private Button clearButton;
    private Button decimalButton;

    private StringBuilder currentNumber;
    private int currentTotal;
    private char currentOperation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayTextView = findViewById(R.id.displayTextView);
        initializeButtons();
        resetCalculator();
    }

    private void initializeButtons() {
        digitButtons = new Button[]{
                findViewById(R.id.buttonZero),
                findViewById(R.id.buttonOne),
                findViewById(R.id.buttonTwo),
                findViewById(R.id.buttonThree),
                findViewById(R.id.buttonFour),
                findViewById(R.id.buttonFive),
                findViewById(R.id.buttonSix),
                findViewById(R.id.buttonSeven),
                findViewById(R.id.buttonEight),
                findViewById(R.id.buttonNine)
        };

        for (Button button : digitButtons) {
            button.setOnClickListener(this);
        }

        operationButtons = new Button[]{
                findViewById(R.id.buttonAdd),
                findViewById(R.id.buttonSubtract),
                findViewById(R.id.buttonMultiply),
                findViewById(R.id.buttonDivide)
        };

        for (Button button : operationButtons) {
            button.setOnClickListener(this);
        }

        equalsButton = findViewById(R.id.buttonEquals);
        equalsButton.setOnClickListener(this);

        clearButton = findViewById(R.id.buttonClear);
        clearButton.setOnClickListener(this);

        decimalButton = findViewById(R.id.buttonDecimal);
        decimalButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Button clickedButton = (Button) view;
        switch (view.getId()) {
            default:
                handleButtonClick(clickedButton);
                break;
        }
    }



    private void handleButtonClick(Button button) {
        String buttonText = button.getText().toString();
        if (isDigit(buttonText) || buttonText.equals(".")) {
            currentNumber.append(buttonText);
            displayTextView.setText(currentNumber.toString());
        } else {
            currentOperation = buttonText.charAt(0);
            displayTextView.setText(String.valueOf(currentOperation));
        }
    }

    private boolean isDigit(String str) {
        return str.matches("\\d");
    }

    private void calculateResult() {
        if (currentOperation != '\u0000') {
            if (currentNumber.length() > 0) {
                int operand = Integer.parseInt(currentNumber.toString());
                switch (currentOperation) {
                    case '+':
                        currentTotal += operand;
                        break;
                    case '-':
                        currentTotal -= operand;
                        break;
                    case '*':
                        currentTotal *= operand;
                        break;
                    case '/':
                        if (operand != 0)
                            currentTotal /= operand;
                        else
                            Toast.makeText(this, "The number cannot be divided by zero.", Toast.LENGTH_SHORT).show();
                        break;
                }
                displayTextView.setText(String.valueOf(currentTotal));
            }
        }
    }

    private void resetCalculator() {
        currentNumber = new StringBuilder();
        currentTotal = 0;
        currentOperation = '\u0000';
        displayTextView.setText("0");
    }
}
