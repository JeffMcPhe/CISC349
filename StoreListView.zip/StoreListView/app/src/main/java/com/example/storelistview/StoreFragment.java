package com.example.storelistview;

import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class StoreFragment extends Fragment {
    private ListView listView;
    private ArrayList<Walmart> walmartStores;
    private ArrayAdapter<Walmart> adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store, container, false);
        listView = view.findViewById(R.id.listView);
        walmartStores = new ArrayList<>();
        adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, walmartStores);
        listView.setAdapter(adapter);
        fetchStoreData();
        return view;
    }

    private void fetchStoreData() {
        String url = "https://nua.insufficient-light.com/data/walmart_store_locations.json";
        RequestQueue queue = Volley.newRequestQueue(requireContext());

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject storeObject = response.getJSONObject(i);
                                String state = storeObject.getString("state");
                                if (state.equalsIgnoreCase("PA")) { // Filter for Pennsylvania stores
                                    String storeName = storeObject.getString("name");
                                    String storeCode = storeObject.optString("index");
                                    String phoneNumber = storeObject.optString("phone_number_1");
                                    String city = storeObject.getString("city");
                                    String streetAddress = storeObject.getString("street_address");
                                    Walmart walmart = new Walmart(storeName, storeCode, phoneNumber, city, streetAddress);
                                    walmartStores.add(walmart);
                                }
                            }
                            adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(requireContext(), "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(jsonArrayRequest);
    }
}
