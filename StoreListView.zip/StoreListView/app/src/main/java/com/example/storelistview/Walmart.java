package com.example.storelistview;

public class Walmart {
    private String storeName;
    private String storeCode;
    private String phoneNumber;
    private String city;
    private String streetAddress;

    public Walmart(String storeName, String storeCode, String phoneNumber, String city, String streetAddress) {
        this.storeName = storeName;
        this.storeCode = storeCode;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.streetAddress = streetAddress;
    }
    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    @Override
    public String toString() {
        return "Store Name: " + storeName + "\n" +
                "Store Code: " + storeCode + "\n" +
                "Phone Number: " + phoneNumber + "\n" +
                "City: " + city + "\n" +
                "Street Address: " + streetAddress;
    }
}
