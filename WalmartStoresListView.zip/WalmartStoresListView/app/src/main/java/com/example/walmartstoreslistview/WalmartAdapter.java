package com.example.walmartstoreslistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class WalmartAdapter extends ArrayAdapter<Walmart> {
    private Context mContext;
    private int mResource;

    public WalmartAdapter(Context context, int resource, List<Walmart> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(mResource, parent, false);
        }

        Walmart store = getItem(position);

        if (store != null) {
            TextView storeInfoTextView = listItem.findViewById(R.id.text_store_info);
            String storeInfo = "Name: " + store.getName() + "\n" +
                    "Code: " + store.getCode() + "\n" +
                    "Phone Number: " + store.getPhoneNumber() + "\n" +
                    "City: " + store.getCity() + "\n" +
                    "Street Address: " + store.getStreetAddress();
            storeInfoTextView.setText(storeInfo);
        }

        return listItem;
    }
}
