package com.example.walmartstoreslistview;

public class Walmart {
    private String name;
    private String code;
    private String phoneNumber;
    private String city;
    private String streetAddress;

    public Walmart(String name, String code, String phoneNumber, String city, String streetAddress) {
        this.name = name;
        this.code = code;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.streetAddress = streetAddress;
    }

    // Add getters and setters for each attribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }
}
