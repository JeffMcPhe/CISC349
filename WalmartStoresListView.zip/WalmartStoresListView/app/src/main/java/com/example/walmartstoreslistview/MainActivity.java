package com.example.walmartstoreslistview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WalmartAdapter adapter;
    private List<Walmart> walmartList;
    private static final String JSON_URL = "https://nua.insufficient-light.com/data/walmart_store_locations.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);
        walmartList = new ArrayList<>();
        adapter = new WalmartAdapter(this, R.layout.list_item, walmartList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Walmart store = walmartList.get(position);
                Toast.makeText(MainActivity.this, store.getName() + ", " + store.getCity(), Toast.LENGTH_SHORT).show();
            }
        });

        parseJson();
    }

    private void parseJson() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, JSON_URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject storeObject = response.getJSONObject(i);

                                String name = storeObject.getString("name");
                                String code = storeObject.getString("code");
                                String phoneNumber = storeObject.getString("phone");
                                String city = storeObject.getString("city");
                                String streetAddress = storeObject.getString("address");

                                Walmart store = new Walmart(name, code, phoneNumber, city, streetAddress);
                                walmartList.add(store);
                            }
                            adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        requestQueue.add(request);
    }
}
