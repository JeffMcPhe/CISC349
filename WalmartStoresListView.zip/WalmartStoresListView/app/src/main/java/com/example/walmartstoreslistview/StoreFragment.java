package com.example.walmartstoreslistview;
import androidx.fragment.app.Fragment;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.view.View;

// StoreFragment.java
public class StoreFragment extends Fragment {
    private TextView storeInfoTextView;

    public StoreFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_store, container, false);

        // Initialize views
        storeInfoTextView = view.findViewById(R.id.text_store_info);

        // Retrieve store information from arguments
        Walmart store = getArguments().getParcelable("store");

        // Display store information
        if (store != null) {
            String storeInfo = "Name: " + store.getName() + "\n" +
                    "Code: " + store.getCode() + "\n" +
                    "Phone Number: " + store.getPhoneNumber() + "\n" +
                    "City: " + store.getCity() + "\n" +
                    "Street Address: " + store.getStreetAddress();
            storeInfoTextView.setText(storeInfo);
        }

        return view;
    }
}
