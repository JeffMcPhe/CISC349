public class HolidaySongs {

    private String albumImg;
    private String albumName;
    private String artistName;
    private Double danceability;
    private Integer durationMs;
    private String playlistImg;

    public HolidaySongs(String albumImg, String albumName, String artistName,
                        Double danceability, Integer durationMs, String playlistImg) {
        this.albumImg = albumImg;
        this.albumName = albumName;
        this.artistName = artistName;
        this.danceability = danceability;
        this.durationMs = durationMs;
        this.playlistImg = playlistImg;
    }

    public String getAlbumImg() {
        return albumImg;
    }

    public void setAlbumImg(String albumImg) {
        this.albumImg = albumImg;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public Double getDanceability() {
        return danceability;
    }

    public void setDanceability(Double danceability) {
        this.danceability = danceability;
    }

    public Integer getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Integer durationMs) {
        this.durationMs = durationMs;
    }

    public String getPlaylistImg() {
        return playlistImg;
    }

    public void setPlaylistImg(String playlistImg) {
        this.playlistImg = playlistImg;
    }
}
