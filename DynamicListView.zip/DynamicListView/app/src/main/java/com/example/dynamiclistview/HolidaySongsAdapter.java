import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class HolidaySongsAdapter extends ArrayAdapter<HolidaySongs> {

    private Context context;
    private ArrayList<HolidaySongs> holidaySongsList;

    public HolidaySongsAdapter(Context context, ArrayList<HolidaySongs> holidaySongsList) {
        super(context, 0, holidaySongsList);
        this.context = context;
        this.holidaySongsList = holidaySongsList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(
                    R.layout.list_item_song, parent, false);
        }

        HolidaySongs currentSong = getItem(position);

        ImageView albumImageView = listItemView.findViewById(R.id.album_image);
        Picasso.get().load(currentSong.getAlbumImg()).into(albumImageView);

        TextView albumNameTextView = listItemView.findViewById(R.id.album_name);
        albumNameTextView.setText(currentSong.getAlbumName());

        TextView artistNameTextView = listItemView.findViewById(R.id.artist_name);
        artistNameTextView.setText(currentSong.getArtistName());

        return listItemView;
    }
}
