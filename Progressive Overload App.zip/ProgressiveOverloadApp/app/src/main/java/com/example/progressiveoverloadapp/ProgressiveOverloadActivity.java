package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProgressiveOverloadActivity extends AppCompatActivity {

    private TextView programTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progressive_overload);

        programTextView = findViewById(R.id.programTextView);

        // Retrieve the input data from Intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String current1RM = extras.getString("current_1RM");
            String goalRM = extras.getString("goal_1RM");

            // Calculate weights and generate program based on the input data
            String programText = generateProgram(current1RM, goalRM);

            // Display the program
            programTextView.setText(programText);
        }
    }

    private String generateProgram(String current1RM, String goalRM) {
        // Parse current 1RM and goal 1RM
        int currentRM = Integer.parseInt(current1RM.replaceAll("[\\D]", ""));
        int adjustedCurrentRM = currentRM - 20; // Adjusted current RM
        int goalRMValue = Integer.parseInt(goalRM.replaceAll("[\\D]", ""));

        // Initialize program text with initial capacity
        StringBuilder programText = new StringBuilder(1000);

        // Calculate the weight progression
        int weightDifference = goalRMValue - adjustedCurrentRM;
        int weeksToAdd = (weightDifference > 25) ? (weightDifference - 25) / 5 : 0;
        int totalWeeks = 5 + weeksToAdd; // Base 5 weeks + additional weeks

        // Define the sets and reps patterns
        String[] patterns = {"5x6", "3x10", "4x7", "6x5"};
        int patternIndex = 0;

        int incrementPerWeek = weightDifference / totalWeeks;
        int currentWeight = adjustedCurrentRM; // Start at adjusted current RM

        // Generate program
        for (int week = 1; week <= totalWeeks; week++) {
            // Add program for current week
            String weekProgram = "Week " + week + ": " + currentWeight + " lbs - " +
                    patterns[patternIndex] + " reps\n";
            programText.append(weekProgram);

            // Increment weight for the next week
            currentWeight += incrementPerWeek;

            // Move to the next pattern
            patternIndex = (patternIndex + 1) % patterns.length;
        }

        return programText.toString();
    }
}
