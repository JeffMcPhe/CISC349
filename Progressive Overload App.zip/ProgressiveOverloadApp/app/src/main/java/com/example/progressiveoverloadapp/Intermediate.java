// Intermediate.java
package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Intermediate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate);

        // Display hardcoded sample workouts for intermediate level
        TextView workoutTextView = findViewById(R.id.workoutTextView);
        workoutTextView.setText("Intermediate Workout\n\n" +
                "1. Barbell Bench Press: 4 sets of 8 reps\n" +
                "2. Deadlifts: 4 sets of 6 reps\n" +
                "3. Pull-ups: 3 sets of maximum reps\n" +
                "4. Bulgarian Split Squats: 3 sets of 10 reps each leg\n");
    }
}
