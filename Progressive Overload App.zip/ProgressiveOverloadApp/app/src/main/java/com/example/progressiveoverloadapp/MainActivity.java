package com.example.progressiveoverloadapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calculateProgressionButton = findViewById(R.id.calculateProgressionButton);
        calculateProgressionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start InputRMActivity to calculate a progression scheme
                startActivity(new Intent(MainActivity.this, InputRMActivity.class));
            }
        });

        Button sampleWorkoutsButton = findViewById(R.id.sampleWorkoutsButton);
        sampleWorkoutsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start SampleWorkoutsActivity to display sample workouts
                startActivity(new Intent(MainActivity.this, SampleWorkoutsActivity.class));
            }
        });

        Button createWorkoutButton = findViewById(R.id.createWorkoutButton);
        createWorkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start CreateWorkoutActivity to create a new workout
                startActivity(new Intent(MainActivity.this, CreateWorkoutActivity.class));
            }
        });
    }
}
