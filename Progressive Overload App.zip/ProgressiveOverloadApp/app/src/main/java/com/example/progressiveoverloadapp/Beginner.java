// Beginner.java
package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Beginner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beginner);

        // Display hardcoded sample workouts for beginners
        TextView workoutTextView = findViewById(R.id.workoutTextView);
        workoutTextView.setText("Beginner Workout\n\n" +
                "1. Push-ups: 3 sets of 10 reps\n" +
                "2. Bodyweight Squats: 3 sets of 12 reps\n" +
                "3. Dumbbell Rows: 3 sets of 10 reps each arm\n" +
                "4. Plank: 3 sets, hold for 30 seconds each\n");
    }
}
