// Elite.java
package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Elite extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elite);

        // Display hardcoded sample workouts for elite level
        TextView workoutTextView = findViewById(R.id.workoutTextView);
        workoutTextView.setText("Elite Workout\n\n" +
                "1. Power Clean and Jerk: 5 sets of 3 reps\n" +
                "2. Front Squats: 5 sets of 5 reps\n" +
                "3. Muscle-ups: 4 sets of maximum reps\n" +
                "4. Barbell Hip Thrusts: 4 sets of 8 reps\n");
    }
}
