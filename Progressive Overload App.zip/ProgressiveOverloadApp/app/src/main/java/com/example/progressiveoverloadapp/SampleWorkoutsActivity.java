package com.example.progressiveoverloadapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;



public class SampleWorkoutsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample_workouts);

        // Find buttons by their IDs
        Button beginnerButton = findViewById(R.id.beginnerButton);
        Button intermediateButton = findViewById(R.id.intermediateButton);
        Button advancedButton = findViewById(R.id.advancedButton);
        Button eliteButton = findViewById(R.id.eliteButton);

        // Set onClickListeners for each button
        beginnerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to BeginnerActivity
                startActivity(new Intent(SampleWorkoutsActivity.this, Beginner.class));
            }
        });

        intermediateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to IntermediateActivity
                startActivity(new Intent(SampleWorkoutsActivity.this, Intermediate.class));
            }
        });

        advancedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to AdvancedActivity
                startActivity(new Intent(SampleWorkoutsActivity.this, Advanced.class));
            }
        });

        eliteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to EliteActivity
                startActivity(new Intent(SampleWorkoutsActivity.this, Elite.class));
            }
        });
    }
}
