package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class CreateWorkoutActivity extends AppCompatActivity {

    private EditText exerciseEditText;
    private EditText weightEditText;
    private EditText repsEditText;
    private Button uploadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_workout);

        exerciseEditText = findViewById(R.id.exerciseEditText);
        weightEditText = findViewById(R.id.weightEditText);
        repsEditText = findViewById(R.id.repsEditText);
        uploadButton = findViewById(R.id.uploadButton);

        uploadButton.setOnClickListener(v -> {
            String exercise = exerciseEditText.getText().toString();
            String weight = weightEditText.getText().toString();
            String reps = repsEditText.getText().toString();

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("exercise", exercise);
                jsonObject.put("weight", weight);
                jsonObject.put("reps", reps);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            uploadWorkoutData(jsonObject.toString());
        });
    }

    private void uploadWorkoutData(String data) {
        new Thread(() -> {
            try {
                URL url = new URL("http://127.0.0.1:5000/create_workout");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
                wr.writeBytes(data);
                wr.flush();
                wr.close();

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Handle success response
                    runOnUiThread(() -> Toast.makeText(CreateWorkoutActivity.this, "Workout uploaded successfully", Toast.LENGTH_SHORT).show());
                } else {
                    // Handle error response
                    runOnUiThread(() -> Toast.makeText(CreateWorkoutActivity.this, "Failed to upload workout", Toast.LENGTH_SHORT).show());
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
