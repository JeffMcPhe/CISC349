package com.example.progressiveoverloadapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class InputRMActivity extends AppCompatActivity {

    private EditText current1RMEditText;
    private EditText goal1RMEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_rm);

        current1RMEditText = findViewById(R.id.current1RMEditText);
        goal1RMEditText = findViewById(R.id.goal1RMEditText);

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve user input from EditText fields
                String current1RM = current1RMEditText.getText().toString();
                String goal1RM = goal1RMEditText.getText().toString();

                // Calculate progressive overload scheme based on the input data
                String programText = generateProgram(current1RM, goal1RM);

                // Pass the input data and the calculated program to ProgressiveOverloadActivity
                Intent intent = new Intent(InputRMActivity.this, ProgressiveOverloadActivity.class);
                intent.putExtra("current_1RM", current1RM);
                intent.putExtra("goal_1RM", goal1RM);
                intent.putExtra("program_text", programText);
                startActivity(intent);

                // Finish this activity
                finish();
            }
        });
    }

    private String generateProgram(String current1RM, String goal1RM) {
        // Calculate the progressive overload scheme based on the input data
        // You can implement your calculation logic here
        // This method should return the generated program text as a String
        // For demonstration purposes, let's return a placeholder program text
        return "This is a placeholder program text for demonstration purposes.";
    }
}
