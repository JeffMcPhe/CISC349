// Advanced.java
package com.example.progressiveoverloadapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Advanced extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced);

        // Display hardcoded sample workouts for advanced level
        TextView workoutTextView = findViewById(R.id.workoutTextView);
        workoutTextView.setText("Advanced Workout\n\n" +
                "1. Overhead Press: 5 sets of 5 reps\n" +
                "2. Barbell Squats: 5 sets of 5 reps\n" +
                "3. Weighted Pull-ups: 4 sets of 6 reps\n" +
                "4. Romanian Deadlifts: 4 sets of 8 reps\n");
    }
}
